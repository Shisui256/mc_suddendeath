execute if score #sd_system sd_cooltime matches ..0 run scoreboard players set #sd_system sd_cooltime 100

scoreboard players remove #sd_system sd_cooltime 1

execute if score #sd_system sd_cooltime matches 2 run function sd_main:game/spawn

execute as @e[tag=sd_bomb] at @s run tp @e[limit=1,sort=nearest,tag=sd_bomb,tag=sd_kaisi] ~ ~-2 ~

execute at @e[tag=sd_kaisi] unless block ~ ~ ~ air unless block ~ ~ ~ water unless block ~ ~ ~ lava run summon minecraft:creeper ~ ~1 ~ {NoAI:1b,Fuse:0,Tags:["sd_cre"],CustomName:'{"text":"SUDDEN DEATH","color":"red","bold":true}'}
execute at @e[tag=sd_kaisi] unless block ~ ~-1 ~ air unless block ~ ~-1 ~ water unless block ~ ~-1 ~ lava run summon minecraft:creeper ~ ~1 ~ {NoAI:1b,Fuse:0,Tags:["sd_cre"],CustomName:'{"text":"SUDDEN DEATH","color":"red","bold":true}'}

execute at @e[tag=sd_kaisi] unless block ~ ~ ~ air unless block ~ ~ ~ water unless block ~ ~ ~ lava run kill @e[limit=1,sort=nearest,tag=sd_bomb,tag=sd_kaisi]
execute at @e[tag=sd_kaisi] unless block ~ ~-1 ~ air unless block ~ ~-1 ~ water unless block ~ ~-1 ~ lava run kill @e[limit=1,sort=nearest,tag=sd_bomb,tag=sd_kaisi]
