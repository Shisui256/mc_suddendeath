kill @e[tag=sd_bomb,tag=!sd_bakuhatsu]

execute at @r run spreadplayers ~ ~ 2 100 false @e[tag=sd_bomb,tag=sd_bakuhatsu]

execute as @e[tag=sd_bomb] at @s run tp @e[limit=1,sort=nearest,tag=sd_bomb] ~ 240 ~

item replace entity @e[tag=sd_bakuhatsu,tag=sd_bomb] armor.head with minecraft:tnt

tag @e[tag=sd_bomb] add sd_kaisi

tag @e[limit=100,sort=random,tag=!sd_sita,tag=!sd_ue,tag=sd_kaisi] add sd_sita
tag @e[limit=100,sort=random,tag=!sd_sita,tag=!sd_ue,tag=sd_kaisi] add sd_ue

execute as @e[tag=sd_sita] at @s run tp @e[limit=1,sort=nearest,tag=sd_bakuhatsu] ~ ~-8 ~
execute as @e[tag=sd_ue] at @s run tp @e[limit=1,sort=nearest,tag=sd_bakuhatsu] ~ ~8 ~
