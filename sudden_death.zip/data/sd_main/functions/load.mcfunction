tellraw @a [{"text":"[ Sudden Death ] ","color":"gold","bold":"true"},{"text":"再読込が完了しました。","color":"white","bold":"true"}]

scoreboard objectives add sd_cooltime dummy
scoreboard objectives add sd_run dummy
