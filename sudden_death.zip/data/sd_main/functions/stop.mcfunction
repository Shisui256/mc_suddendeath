scoreboard players set #sd_system sd_run 0

gamerule mobGriefing true

forceload remove 0 0
