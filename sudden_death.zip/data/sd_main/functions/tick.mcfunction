execute if score #sd_system sd_run matches 1 run function sd_main:game/tick
