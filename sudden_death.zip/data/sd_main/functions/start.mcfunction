scoreboard players set #sd_system sd_run 1

scoreboard players remove #sd_system sd_cooltime 1

gamerule mobGriefing false

forceload add 0 0
